# pythonista-scripts

My collections of little scripts for [Pythonista](http://omz-software.com/pythonista/index.html)

Most of these are several years old and might be broken by now
