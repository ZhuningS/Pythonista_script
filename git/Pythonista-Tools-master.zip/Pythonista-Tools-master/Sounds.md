# Sounds

GitHub Repos
------------

GitHub Gists
------------

| Script Name        | Description   | 
| -------------      | ------------- | 
| [Sound Demo][]   | Simple demo of playing a looping sound using the (currently undocumented) `sound.Player` class |
| [Sounder][]      | This script plays each .caf sound inside of Pythonista.app      |
| [The Blues][]    | This script plays a blues melody on Pythonista      |


[Sound Demo]: https://gist.github.com/omz/10023837
[Sounder]: https://gist.github.com/cclauss/6462976
[The Blues]: https://gist.github.com/cclauss/5073235
