# Fun

Programs and scripts for fun.

GitHub Repos
------------
	
| Script Name                        | Description                | 
| ---------------------------------- | -------------------------- | 
| [XKCD viewer][]                    | UI application for browsing XKCD webcomics |
| [cNotif][]                         | Custom Notification for Pythonista - Send custom text and open an app with its x-callback-url in order to make the notification appear at the top of the screen |
| [DownloadRedditComments][]         | Download Reddit Comments & save to file |

GitHub Gists
------------

[XKCD viewer]: https://github.com/Ivoah/XKCD-viewer
[cNotif]: https://github.com/GoDzM4TT3O/cNotif
[DownloadRedditComments]: https://github.com/GoDzM4TT3O/DRC
