# Pythonista

Collection of Python Scripts written for [Pythonista iOS App](http://omz-software.com/pythonista/).

I try to sort these scripts into @Folders after functionality, purpose or use for.

The most of them are forked from other github repositories but referenced at the beginning of each script, others are collected from the [omz:forum](https://forum.omz-software.com), or other coding communities.

I maintain this repo as a backup for all my Pythonista Scripts.

Changes, Forks and Pulls are welcomed for the wealth of the Pythonista Community.
