# https://stackoverflow.com/questions/13459856/how-can-i-create-a-simple-python-brute-force-function

import random
a_z = "abcdefghijklmnopqrstuvwxyz_0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
while password != curtry:
    leng = random.randint(4,12) #random int between 4 and 12
    i = 0
    curtry = "lol"
    for i<leng:
         curtry += random.choice(a_z)
