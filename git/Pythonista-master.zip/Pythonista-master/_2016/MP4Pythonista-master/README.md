# MP4Pythonista

Music Player for "Pythonista 3"

## Requirement

* [Pythonista 3](http://omz-software.com/pythonista/)
* [StaSh](https://github.com/ywangd/stash)
    * To install with git

## Installation

    $ git clone https://github.com/mogira/MP4Pythonista.git MP4Pythonista

