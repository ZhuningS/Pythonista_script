# https://forum.omz-software.com/topic/3823/file-downloader

import urllib.request
urllib.request.urlretrieve("direct link to file", "filename.extension")
