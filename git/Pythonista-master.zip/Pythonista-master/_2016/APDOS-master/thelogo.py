import console, time, speech
def logo():
	console.set_color()
	console.set_font('AnonymousPro-Bold', 15.35)
	print "# -=-=-=-=-=-=- #  # -=-=-=-=-=-=- #"
	print ""
	print "     ____.------''''--.___"
	print "         ____.----'---._/ '--"
	print "              __.----./ '--"
	print "                    / '-"
	print "            __..--------..__"
	print "         _-'              '----'"
	print "        ||"
	print "        ||"
	print "        '.__   Savage"
	print "            '--------."
	print "            Official ''-."
	print "                        |'."
	print "                       /  |"
	print "                    __/__.'"
	print "                   ' /"
	print ""
	print "# -=-=-=-=-=-=- #  # -=-=-=-=-=-=- #"
	print ""
logo()
speech.say("Welcome To APDOS")
time.sleep(1)
speech.say("Powered by Sav Sec")
time.sleep(3)
console.set_font()
console.clear()
# SavSec / Savage Official Logo in ACSII (c) 2016
