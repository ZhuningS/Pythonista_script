# https://github.com/russianotter/apdos

# APDOS
APDOS is a Denail Of Service Program developed by Sav-SEC / SAVAGEO. Need Help? @savsec.russianotter (insta)

#MOST POWERFUL DDoS ON iOS 10

# Basics
This is a extremely simple DDOS client.
It's main purpose is to show off the possibility
of denial of service from an iOS device running
Pythonista 3 (in a funny way). As time 
progresses I might make it stronger. Hello to all 
the NSA agents out there who might skim over this!

# Requirements
-A brain
-Python 2.7
-Pythonista 3
-Wifi or Ethernet
-And the ability to type

# Argv Numbers Increase Attack

APDOS is not made for malisous use.
I am not responsible for your misconduct.
