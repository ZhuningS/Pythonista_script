# https://forum.omz-software.com/topic/3733/notification-module-help

dalay=time.mktime(time.strptime('20191231 1159','%Y%m%d %H%M'))-time.time()
