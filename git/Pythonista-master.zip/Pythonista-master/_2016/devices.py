# https://github.com/zacbir/pythonista

# pythonista doubles pixels on a retina display, so you really only need half size
ipad = (512.0, 512.0)
ipad_r = (1024.0, 1024.0)
ipad_r_ios7 = (1262.0, 1262.0)
iphone = (160.0, 240.0)
iphone_r = (320.0, 480.0)
iphone_5 = (320.0, 568.0)
iphone_5_ios7 = (372.0, 696.0)
mbp_r = (1440.0, 900.0)
cinema = (1280.0, 800.0)
