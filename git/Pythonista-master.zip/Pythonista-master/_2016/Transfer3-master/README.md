# Transfer3 [Pythonista]

Trasnfer files by https.
This program may be diffucult to read due to its difficulties and my coding ability sorry!!

***This program is beta.
if there is an error, please restart pythonista

Todo
Support windows by pyqt
More stable
