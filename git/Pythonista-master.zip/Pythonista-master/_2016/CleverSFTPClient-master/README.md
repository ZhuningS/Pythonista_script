# CleverSFTPClient
Very practical Pythonista SFTPClient application

## Feature
* Auto scanning ssh port

* You can connect by passkey (password phrase)

* You can upload/download multiple files/folders

* You can upload/download folders and its subfolders

* You can run ssh command via stash

* You can edit files by Pythonista editor

