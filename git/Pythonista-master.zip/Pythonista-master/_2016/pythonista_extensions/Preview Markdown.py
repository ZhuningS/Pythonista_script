# coding: utf-8

# https://gitlab.com/atronah/pythonista_extensions/tree/master

import appex
from libs.preview import process_sources

def main():
    process_sources('md')
    

if __name__ == '__main__':
    main()

