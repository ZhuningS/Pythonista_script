# https://forum.omz-software.com/topic/3950/least-to-greatest/2

numbers = (55, -55, 5, -5, 0.005, -0.005, 0)
print(sorted(numbers))
# --------------------
print(sorted(input()))
# --------------------
[' ', ' ', ' ', ',', ',', ',', '4', '5', '6', '7']
# --------------------
input()# --------------------
str# --------------------
sorted# --------------------
sorted('bca')# --------------------
['a', 'b', 'c']# --------------------
split# --------------------
sorted(input().split(','))# --------------------
sorted([int(x) for x in input().split(',')])
# --------------------
sorted(ast.literal_eval(input()))
# --------------------
print(sorted(input().replace(',', ' ').split()))
