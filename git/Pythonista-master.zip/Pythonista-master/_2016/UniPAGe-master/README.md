# UniPAGe
A Universal Python Adaptable GUI extension
