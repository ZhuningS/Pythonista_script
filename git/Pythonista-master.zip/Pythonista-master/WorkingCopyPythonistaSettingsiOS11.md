# https://github.com/humberry/WorkingCopy

Github, Pythonista 3.2, Working Copy 3.2.2, iOS 11.2.1

Settings:
1) Settings => Identities => + => Name and Email (...@user.noreply.github.com)
2) SSH Keys => + => Generate Key => Connect with GitHub

Clone:
1) + => Clone repository => Choose one of your repos or Enter URL (git@github.com:user/repo.git) => Clone

Edit repo in Pythonista:
1) Open Pythonista => + => Import => Files => Working Copy (first time => search => enable) => Select Folder => Open

Push repo:
1) Edit => Selcet Folder in Pythonista => Open In => Save in Working Copy (first time => enable it) => Save as directory => Choose your repo
2) Open Working Copy => Open repo => Commit changes => select your file or all => short summary => Commit

Initialize repository:
1) + => Initialize repository
2) Repository Name => Create
3) Add Remote
4) Create Repository
5) Github => Public => Confirm Create
6) Create/Import files
7) Commit changes => select your file or all => short summary => Commit

Remove repository from your device:
1) Open the repo folder
2) Delete from iPxxx
=> repo still exists at Github

Update repos:
1) Just swipe down in the Repositories view
