local test package for stash pip
