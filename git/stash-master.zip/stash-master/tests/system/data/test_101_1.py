# coding=utf-8
from __future__ import print_function
import time

for i in range(2):
    print('sleeping ... {}'.format(i))
    time.sleep(1)