#!/bin/bash

# Ensure a script can correctly receive piped input

cat tests/system/data/test10.sh | test10_1.sh
