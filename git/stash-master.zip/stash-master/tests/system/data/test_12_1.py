import os

os.chdir('bin')