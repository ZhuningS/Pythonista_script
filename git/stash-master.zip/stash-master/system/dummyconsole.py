
def hud_alert(msg, icon, duration):
    pass

def show_activity():
    pass

def hide_activity():
    pass

