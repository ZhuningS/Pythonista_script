#!/usr/bin/python3
# -*- coding: UTF-8 -*-

import requests

req = requests.get('http://www.baidu.com')
print(req
      )
