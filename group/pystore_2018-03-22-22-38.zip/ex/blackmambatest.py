#!python3

import blackmamba as bm
bm.main()
