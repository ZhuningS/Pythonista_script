#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @File    : show_help.py
# @Author  : loli
# @Date    : 2018-03-15
# @Version : 1.0
# @Contact : https://t.me/weep_x
# @tg group: https://t.me/pythonista3dalaoqun

import common
from core.ui2 import ui_help
